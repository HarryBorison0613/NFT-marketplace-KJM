import { createContext } from 'react';

const WalletContext = createContext();

export default WalletContext;
