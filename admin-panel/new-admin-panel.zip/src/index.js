import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';
import { MoralisProvider } from "react-moralis";
import App from './App';

ReactDOM.render(
  <React.StrictMode>
    <MoralisProvider appId="TuS0Np7a0s5DeDZ0CbgOM796MnPm6SKl2tyHVxoS" serverUrl="https://dkegezgeevia.usemoralis.com:2053/server">
      <App />
    </MoralisProvider>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
