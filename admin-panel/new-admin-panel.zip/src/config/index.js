const config = {
  backend_url: 'https://opera.api.novanetwork.io:9070/api',
  graph_url: 'https://api.thegraph.com/subgraphs/name/patriotze/operahouse2',
  marketplaceAddress: "0x0a179c630a0bcf230f73a9a6856e1fec42018bda",
  defaultCollectionAddress: '0x86c4764a936b0277877cb83abf1ad79ce35c754c'
}

export default config
